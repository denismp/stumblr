/**
 * Entities that Stumblr deals with.
 */
package com.rnsolutions.stumblr.entity;
