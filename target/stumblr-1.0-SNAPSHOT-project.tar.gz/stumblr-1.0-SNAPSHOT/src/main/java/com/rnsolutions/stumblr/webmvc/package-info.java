/**
 * Spring MVC based presentation tier.
 */
package com.rnsolutions.stumblr.webmvc;
