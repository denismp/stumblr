/**
 * Core support classes for the project.  Helps make the project more uniform by
 * providing common implementations for the DAO tier of the application.
 */
package com.rnsolutions.core.dao;
