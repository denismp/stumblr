/**
 * Data tier for persisting information.
 */
package com.rnsolutions.stumblr.dao;
