/**
 * The service or business teir for the application.
 */
package com.rnsolutions.stumblr.service;
